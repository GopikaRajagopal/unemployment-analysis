"""
Unemployment Analysis with Python
---------------------------------
Run:
    pip install -r requirements.txt
    python unemployment_analysis.py --data "Unemployment in India.csv"

The script expects a CSV containing columns similar to:
Region, Date, Estimated Unemployment Rate (%), Estimated Employed,
Estimated Labour Participation Rate (%), Area
Column names are normalized automatically.
"""

import argparse
import re
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


def normalize_column(name):
    """Normalize column names so small spacing/case differences are tolerated."""
    name = str(name).strip().lower()
    name = re.sub(r"[^a-z0-9]+", "_", name)
    return name.strip("_")


def find_column(columns, candidates):
    for candidate in candidates:
        if candidate in columns:
            return candidate
    return None


def main():
    parser = argparse.ArgumentParser(description="Analyze unemployment trends.")
    parser.add_argument("--data", default="Unemployment in India.csv",
                        help="Path to the unemployment CSV file.")
    parser.add_argument("--output", default="graphs",
                        help="Directory in which charts and summary CSVs are saved.")
    args = parser.parse_args()

    data_path = Path(args.data)
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    if not data_path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {data_path}. Download the dataset and pass its path "
            "using --data."
        )

    df = pd.read_csv(data_path)
    df.columns = [normalize_column(c) for c in df.columns]

    date_col = find_column(df.columns, ["date"])
    region_col = find_column(df.columns, ["region", "state"])
    area_col = find_column(df.columns, ["area"])
    rate_col = find_column(
        df.columns,
        ["estimated_unemployment_rate", "estimated_unemployment_rate_percent",
         "unemployment_rate", "unemployment_rate_percent"]
    )
    employed_col = find_column(
        df.columns, ["estimated_employed", "employed", "employment"]
    )
    participation_col = find_column(
        df.columns,
        ["estimated_labour_participation_rate",
         "estimated_labour_participation_rate_percent",
         "labour_participation_rate"]
    )

    if not date_col or not rate_col:
        raise ValueError(
            "Could not identify the Date and unemployment-rate columns. "
            f"Columns found: {list(df.columns)}"
        )

    # Clean numeric fields and dates.
    df[date_col] = pd.to_datetime(df[date_col].astype(str).str.strip(),
                                  dayfirst=True, errors="coerce")
    numeric_cols = [rate_col]
    if employed_col:
        numeric_cols.append(employed_col)
    if participation_col:
        numeric_cols.append(participation_col)

    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    before_rows = len(df)
    df = df.drop_duplicates()
    df = df.dropna(subset=[date_col, rate_col]).copy()
    print(f"Rows before cleaning: {before_rows}")
    print(f"Rows after cleaning:  {len(df)}")
    print(f"Removed rows:         {before_rows - len(df)}")
    print("\nMissing values after cleaning:")
    print(df.isna().sum())

    if df.empty:
        raise ValueError("No valid rows remain after cleaning. Check the dataset.")

    sns.set_theme(style="whitegrid")
    plt.rcParams["figure.figsize"] = (11, 6)

    print("\nOverall unemployment statistics:")
    print(df[rate_col].describe().round(2))
    print(f"\nOverall average unemployment rate: {df[rate_col].mean():.2f}%")

    # 1. Time trend: average across all available regions for each date.
    monthly = df.groupby(date_col)[rate_col].mean().sort_index()
    monthly.to_csv(output_dir / "unemployment_time_series.csv", header=["average_rate"])
    plt.figure()
    plt.plot(monthly.index, monthly.values, marker="o", linewidth=1.8)
    plt.title("Unemployment Rate Over Time")
    plt.xlabel("Date")
    plt.ylabel("Average unemployment rate (%)")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(output_dir / "unemployment_over_time.png", dpi=160)
    plt.close()

    # 2. Regional comparison.
    if region_col:
        regional = df.groupby(region_col)[rate_col].mean().sort_values(ascending=False)
        regional.to_csv(output_dir / "regional_unemployment.csv", header=["average_rate"])
        plt.figure(figsize=(12, 7))
        regional.sort_values().plot(kind="barh")
        plt.title("Average Unemployment Rate by Region")
        plt.xlabel("Average unemployment rate (%)")
        plt.ylabel("Region")
        plt.tight_layout()
        plt.savefig(output_dir / "regional_unemployment.png", dpi=160)
        plt.close()
        print("\nFive regions with highest average unemployment:")
        print(regional.head(5).round(2))

    # 3. COVID comparison. This is a descriptive before/after comparison,
    # not proof that COVID alone caused the difference.
    before = df[df[date_col] < "2020-03-01"][rate_col]
    during = df[df[date_col] >= "2020-03-01"][rate_col]
    if not before.empty and not during.empty:
        before_mean = before.mean()
        during_mean = during.mean()
        difference = during_mean - before_mean
        print("\nCOVID-19 period comparison:")
        print(f"Before March 2020 average: {before_mean:.2f}%")
        print(f"March 2020 onward average: {during_mean:.2f}%")
        print(f"Difference: {difference:+.2f} percentage points")

        plt.figure(figsize=(8, 5))
        plt.bar(["Before Mar 2020", "Mar 2020 onward"],
                [before_mean, during_mean])
        plt.title("Unemployment: Before vs. During COVID-19 Period")
        plt.ylabel("Average unemployment rate (%)")
        plt.tight_layout()
        plt.savefig(output_dir / "covid_comparison.png", dpi=160)
        plt.close()
    else:
        print("\nCOVID comparison skipped: dataset needs observations on both sides "
              "of March 2020.")

    # 4. Month-of-year pattern. Treat this as an exploratory seasonal pattern;
    # several years of data are preferable for confirming seasonality.
    df["month"] = df[date_col].dt.month
    seasonal = df.groupby("month")[rate_col].mean().reindex(range(1, 13))
    seasonal.to_csv(output_dir / "monthly_pattern.csv", header=["average_rate"])
    plt.figure(figsize=(10, 5))
    plt.plot(seasonal.index, seasonal.values, marker="o")
    plt.xticks(range(1, 13),
               ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"])
    plt.title("Average Unemployment Rate by Calendar Month")
    plt.xlabel("Month")
    plt.ylabel("Average unemployment rate (%)")
    plt.tight_layout()
    plt.savefig(output_dir / "seasonal_monthly_pattern.png", dpi=160)
    plt.close()

    # 5. Rural/urban comparison.
    if area_col:
        area = df.groupby(area_col)[rate_col].mean().sort_values(ascending=False)
        area.to_csv(output_dir / "area_comparison.csv", header=["average_rate"])
        plt.figure(figsize=(7, 5))
        area.plot(kind="bar")
        plt.title("Average Unemployment Rate: Area Comparison")
        plt.xlabel("Area")
        plt.ylabel("Average unemployment rate (%)")
        plt.xticks(rotation=0)
        plt.tight_layout()
        plt.savefig(output_dir / "rural_urban_comparison.png", dpi=160)
        plt.close()

    # 6. Correlation heatmap, when at least two numeric measures are available.
    corr_cols = [c for c in [rate_col, employed_col, participation_col] if c]
    if len(corr_cols) >= 2:
        corr = df[corr_cols].corr(numeric_only=True)
        corr.to_csv(output_dir / "correlation_matrix.csv")
        plt.figure(figsize=(8, 6))
        sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
        plt.title("Correlation Between Employment Indicators")
        plt.tight_layout()
        plt.savefig(output_dir / "correlation_heatmap.png", dpi=160)
        plt.close()

    print(f"\nAnalysis complete. Outputs saved in: {output_dir.resolve()}")


if __name__ == "__main__":
    main()
